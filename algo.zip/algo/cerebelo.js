document.getElementById("button").onclick = function () {
    alert("tomaaa!!")
}
